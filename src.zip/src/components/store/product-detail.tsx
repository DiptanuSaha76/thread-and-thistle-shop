import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import {
  Heart,
  ChevronLeft,
  ChevronRight,
  ShoppingBag,
  ArrowRight,
  Truck,
  Ruler,
  Check,
  MapPin,
  LoaderCircle,
  AlertCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Breadcrumb, Swatches, Quantity, Benefits, Related, Modal } from "./shared";
import { useStore } from "@/lib/store/state";
import { inBagAfter, MAX_PER_LINE, remainingFor } from "@/lib/store/bag";
import { Reviews } from "./reviews";
import { money, sizes, imageFor, productColours, productSizes, stock, type Product } from "@/lib/store/catalogue";

export function ProductDetail({ product }: { product: Product }) {
  const store = useStore(),
    navigate = useNavigate();
  const [colour, setColour] = useState(product.colour),
    [size, setSize] = useState(""),
    [quantity, setQuantity] = useState(1),
    [error, setError] = useState(""),
    [guide, setGuide] = useState(false),
    [index, setIndex] = useState(0);

  // Demo-only PIN checker: validates the format and simulates loading.
  // It does not check real courier serviceability or delivery dates.
  const [pin, setPin] = useState(""),
    [pinError, setPinError] = useState(""),
    [checkingPin, setCheckingPin] = useState(false),
    [pinChecked, setPinChecked] = useState(false);

  const extra = (product.images ?? []).filter((x) => x !== imageFor(product, colour));
  const images = [imageFor(product, colour), ...extra, product.image]
    .filter((x, i, a) => x && a.indexOf(x) === i)
    .slice(0, 6);
  const productSizeList = productSizes(product);
  const available = stock(product, colour, size) > 0;

  const checkPin = async () => {
    if (!/^\d{6}$/.test(pin)) {
      setPinError("Please enter a valid 6-digit PIN code.");
      setPinChecked(false);
      return;
    }

    setPinError("");
    setPinChecked(false);
    setCheckingPin(true);
    // Intentional short delay for the demo loading animation only.
    await new Promise((resolve) => setTimeout(resolve, 1200));
    setCheckingPin(false);
    setPinChecked(true);
  };

  // How many more of this colour/size can go in the bag (stock and the per-item limit,
  // minus what is already there). The picker never offers more than that.
  const left = size
    ? remainingFor(
        store.cart,
        { productId: product.id, colour, size },
        stock(product, colour, size),
      )
    : MAX_PER_LINE;
  const pick = Math.max(1, Math.min(quantity, left));
  const add = (buy = false) => {
    if (!size) {
      setError("Please select a size before adding to your bag.");
      return;
    }
    if (!available) return;
    const line = { productId: product.id, colour, size, quantity: pick };
    // Buy now makes sure the item is in the bag; it does not add a second one.
    const outcome = store.add(line, buy ? { mode: "ensure" } : undefined);
    setError("");
    if (buy && inBagAfter(outcome)) navigate({ to: "/checkout" });
  };

  return (
    <>
      <div className="container product-page">
        <Breadcrumb name={product.name} />
        <div className="product-detail-layout">
          <div className="gallery">
            <div className="thumbnails">
              {images.map((image, i) => (
                <Button
                  key={i}
                  variant="outline"
                  className={index === i ? "thumbnail selected" : "thumbnail"}
                  aria-label={`View image ${i + 1}`}
                  onClick={() => setIndex(i)}
                >
                  <img src={image} alt={`${product.name} view ${i + 1}`} />
                </Button>
              ))}
            </div>
            <div className={`main-product-image gallery-view-${index}`}>
              <img
                src={images[index] ?? images[0]}
                alt={`${colour} oversized t-shirt, view ${index + 1}`}
                width="480"
                height="1024"
              />
              <Button
                variant="floating"
                size="icon"
                className="heart-control"
                aria-label="Toggle product wishlist"
                aria-pressed={store.wishlist.includes(product.id)}
                onClick={() => store.wish(product.id)}
              >
                <Heart className={store.wishlist.includes(product.id) ? "heart-filled" : ""} />
              </Button>
              <Button
                variant="floating"
                size="icon"
                className="gallery-prev"
                aria-label="Previous image"
                onClick={() => setIndex((index + images.length - 1) % images.length)}
              >
                <ChevronLeft />
              </Button>
              <Button
                variant="floating"
                size="icon"
                className="gallery-next"
                aria-label="Next image"
                onClick={() => setIndex((index + 1) % images.length)}
              >
                <ChevronRight />
              </Button>
              <span className="image-count">{index + 1} / {images.length}</span>
            </div>
          </div>

          <div className="product-info">
            {product.badge && <span className="info-badge">{product.badge}</span>}
            <h1>{product.name.toUpperCase()}</h1>
            <p className="detail-rating">
              ★★★★★{" "}
              <span>
                {product.rating} · {product.reviews} customer reviews
              </span>
            </p>
            <div className="detail-price">
              {money(product.price)}
              <small>Inclusive of all taxes</small>
            </div>
            <p className="product-description">
              {product.description ||
                "Premium oversized t-shirt made with 240 GSM cotton. Designed for everyday comfort with a relaxed fit."}
            </p>

            <div className="variant-group">
              <p>
                Colour: <b>{colour}</b>
              </p>
              <Swatches
                names={productColours(product)}
                selected={colour}
                onChange={(c) => {
                  setColour(c);
                  setIndex(0);
                }}
              />
            </div>

            <div className="variant-group">
              <div className="size-label">
                <p>
                  Size: <b>{size || "Select size"}</b>
                </p>
                <Button variant="link" size="sm" onClick={() => setGuide(true)}>
                  <Ruler />
                  Size Guide
                </Button>
              </div>
              <div className="size-row">
                {productSizeList.map((s) => (
                  <Button
                    key={s}
                    disabled={stock(product, colour, s) === 0}
                    variant={s === size ? "default" : "outline"}
                    aria-pressed={s === size}
                    onClick={() => {
                      setSize(s);
                      setError("");
                    }}
                  >
                    {s}
                  </Button>
                ))}
              </div>
              {error && (
                <p className="field-error" role="alert">
                  {error}
                </p>
              )}
            </div>

            <div className="purchase-meta">
              <Quantity value={pick} onChange={setQuantity} max={Math.max(1, left)} />
              <span className={available ? "stock text-success" : "stock text-destructive"}>
                <Check size={14} />
                {available ? "In Stock" : "Out of stock"}
              </span>
            </div>

            {/* Demo-only PIN UI; no live delivery-service lookup is performed. */}
            <section className="pin-checker" aria-labelledby="pin-checker-title">
              <label id="pin-checker-title" className="pin-checker-label" htmlFor="delivery-pin">
                Check delivery availability
              </label>
              <div className="pin-checker-row">
                <div className={`pin-checker-input-wrap${pinError ? " has-error" : ""}`}>
                  <MapPin size={17} aria-hidden="true" />
                  <input
                    id="delivery-pin"
                    type="text"
                    inputMode="numeric"
                    autoComplete="postal-code"
                    maxLength={6}
                    placeholder="Enter 6-digit PIN code"
                    value={pin}
                    aria-invalid={Boolean(pinError)}
                    aria-describedby={pinError ? "pin-error" : "pin-demo-note"}
                    onChange={(event) => {
                      setPin(event.target.value.replace(/\D/g, "").slice(0, 6));
                      setPinError("");
                      setPinChecked(false);
                    }}
                    onKeyDown={(event) => {
                      if (event.key === "Enter") {
                        event.preventDefault();
                        void checkPin();
                      }
                    }}
                  />
                </div>
                <Button
                  type="button"
                  variant="outline"
                  className="pin-check-button"
                  disabled={checkingPin}
                  onClick={() => void checkPin()}
                >
                  {checkingPin ? <LoaderCircle className="pin-spinner" size={16} /> : null}
                  {checkingPin ? "Checking…" : "Check PIN"}
                </Button>
              </div>

              {pinError ? (
                <p className="pin-feedback pin-feedback-error" id="pin-error" role="alert">
                  <AlertCircle size={15} /> {pinError}
                </p>
              ) : checkingPin ? (
                <div className="pin-loading" role="status" aria-live="polite">
                  <span className="pin-loading-track"><span /></span>
                  <span>Running demo check…</span>
                </div>
              ) : pinChecked ? (
                <div className="pin-result" role="status" aria-live="polite">
                  <p className="pin-feedback pin-feedback-success">
                    <Check size={15} /> Demo check complete for PIN {pin}.
                  </p>
                  <p className="delivery pin-shipping-text">
                    <Truck size={17} /> Ships in 1–2 days · Pan India delivery
                  </p>
                  <p className="pin-demo-note" id="pin-demo-note">
                    Demo preview only — actual delivery serviceability and timelines have not been verified.
                  </p>
                </div>
              ) : (
                <p className="pin-demo-note" id="pin-demo-note">
                  UI demo only. Enter any 6-digit PIN to preview the shipping message; no live serviceability check is made.
                </p>
              )}
            </section>

            <Button size="lg" className="full-button" disabled={!available} onClick={() => add()}>
              <ShoppingBag />
              ADD TO CART <ArrowRight />
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="full-button"
              disabled={!available}
              onClick={() => add(true)}
            >
              BUY NOW <ArrowRight />
            </Button>
            <Benefits compact />
            <div className="product-accordions">
              {[
                [
                  "Product Details",
                  "100% premium cotton. 240 GSM heavyweight fabric with a clean crew neck and dropped shoulders.",
                ],
                [
                  "Size & Fit",
                  "Relaxed oversized silhouette. Choose your usual size for an oversized fit, or size down for a closer fit.",
                ],
                [
                  "Shipping & Returns",
                  "Ships in 1–2 days. Free shipping on orders above ₹999; ₹79 otherwise. 7 days easy returns & exchanges.",
                ],
                [
                  "Care Instructions",
                  "Machine wash cold, inside out with similar colours. Do not bleach. Dry in shade. Iron on low heat.",
                ],
              ].map(([title, text]) => (
                <details key={title}>
                  <summary>{title}</summary>
                  <p>{text}</p>
                </details>
              ))}
            </div>
          </div>
        </div>
      </div>
      <Reviews product={product} />
      <Related exclude={product.id} />
      <Modal
        open={guide}
        onOpenChange={setGuide}
        title="Size Guide"
        description="Oversized fit · Measurements in inches"
      >
        <table className="size-table">
          <thead>
            <tr>
              <th>Size</th>
              <th>Chest</th>
              <th>Length</th>
              <th>Shoulder</th>
            </tr>
          </thead>
          <tbody>
            {sizes.map((s, i) => (
              <tr key={s}>
                <th>{s}</th>
                <td>{40 + i * 2}</td>
                <td>{27 + i}</td>
                <td>{20 + i}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <p>
          Choose your usual size for our signature oversized fit. Measurements are approximate and
          may vary by up to 1 inch.
        </p>
      </Modal>
    </>
  );
}

